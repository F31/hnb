# Change: 新增应用全生命周期管理能力 (add-app-lifecycle-management)

## Why

当前 `app-market` 只解决了"应用从哪里来"（OCI 存储、Helm Chart 同步、目录浏览），而 `operation-worker`、`gateway-provider`、`alert-manager`、`cluster-router` 等模块具备编排、流量、告警、多集群分发的原子能力，但彼此之间没有被串联成面向"一个运行中应用"的闭环视图。运维人员今天要完成一次灰度升级，需要手动组合网关规则、Helm 操作、监控查询三套系统，且没有统一的发布历史和回滚入口。

这导致三个具体问题：
1. **无法追踪运行态**：应用市场知道"有哪些 Chart"，但不知道"哪些集群正跑着哪个版本、是否健康"。
2. **发布是单点操作**：升级 = 重新执行一次 Helm install，没有滚动策略、灰度策略、失败自动回滚。
3. **闭环缺失**：应用市场发布新版本后，运行中的实例不会收到通知，也无法一键评估差异并升级。

本变更引入 **应用生命周期管理（App Lifecycle Management）** 能力，作为连接 app-market（目录/制品）与 cluster-router / operation-worker / gateway-provider / alert-manager（执行/流量/监控）的中间层，交付部署、升级（滚动 & 灰度）、扩缩容、监控、回滚的统一闭环。

## What Changes

- **新增能力 `app-lifecycle`**：应用实例（AppInstance）模型、生命周期状态机、部署/升级/灰度/回滚/扩缩容/卸载的完整需求集。
- **扩展 `operation-worker`**：新增一组 App Lifecycle Operation 插件（Install / Upgrade / Canary / Scale / Rollback / Uninstall），复用现有微内核编排引擎、重试与 NATS 任务队列，而非新建二进制。
- **扩展 `app-market`（MODIFIED）**：目录条目发布新版本时对外发出版本事件；目录详情页关联展示该条目当前有哪些运行实例。
- **扩展 `gateway-provider`（MODIFIED）**：新增按权重的流量分割能力，供灰度发布使用。
- **扩展 `alert-manager` 集成（非本次变更的 spec 修改，但作为依赖）**：每个 AppInstance 自动生成一组默认健康/资源告警规则。
- **新增 API**：`apiserver` 下新增 `/api/v1/app-instances` 系列端点（创建、升级、灰度、扩缩容、回滚、卸载、发布历史查询）。
- **新增控制台页面**：应用实例列表、实例详情（版本历史、健康面板、灰度进度条）。

**BREAKING**: 无。本变更为新增能力，不改变现有 `app-market`、`gateway-provider` 已有需求的行为，仅追加新需求。

## Impact

- **受影响的 spec**：`app-lifecycle`（新增）、`app-market`（追加需求）、`gateway-provider`（追加需求）
- **受影响的代码**（预期，非本文档强制）：
  - `pkg/appstore`（复用制品与 Helm 同步能力）
  - `cmd/operation-worker`、`pkg/core`（新增 Operation 插件类型）
  - `cmd/gateway-provider`（新增加权路由规则 API）
  - `cmd/app-market`（新增版本事件发布）
  - `cmd/apiserver`（新增路由与鉴权中间件挂载）
  - `pkg/iam`（新增 `app-instance` 资源类型的 RBAC 动作：deploy/upgrade/scale/rollback/uninstall）
  - `pkg/audit`（新增事件类型）
  - 数据库：新增迁移（AppInstance、AppRelease、CanaryRollout 等表，编号续接现有 23 个迁移）
- **不涉及**：RKE2/K3s Provider、前端框架选型等其他路线图项，属于并行工作，无依赖冲突。
