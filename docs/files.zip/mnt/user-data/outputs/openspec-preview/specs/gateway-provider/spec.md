## ADDED Requirements

### Requirement: 加权流量分割路由
网关管理 SHALL 支持在同一服务的两个后端版本（如 stable 与 canary）之间按权重百分比分割流量，并支持通过 API 动态调整权重。

#### Scenario: 创建加权路由规则
- **WHEN** 上层能力（如应用生命周期管理）为某服务提交 stable/canary 两个后端及初始权重（如 100/0）
- **THEN** 网关 SHALL 建立对应的流量分割规则并按权重转发请求

#### Scenario: 动态调整权重
- **WHEN** 已存在的加权路由规则收到新的权重值（如 canary 从 10% 调整为 30%）
- **THEN** 网关 SHALL 在不中断现有连接的前提下按新权重生效，且调整过程 SHALL 在 5 秒内完成生效

#### Scenario: 权重规则清理
- **WHEN** 上层能力请求删除某加权路由规则（灰度晋升或中止后）
- **THEN** 网关 SHALL 移除该规则，全部流量回归唯一后端，且不产生残留配置
