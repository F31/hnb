## ADDED Requirements

### Requirement: 从应用市场目录部署应用实例
系统 SHALL 允许具备部署权限的用户，从 `app-market` 目录条目的指定版本创建一个应用实例（AppInstance），并将其部署到指定集群与命名空间。

#### Scenario: 从目录一键部署成功
- **WHEN** 用户选择目录条目版本、目标集群、目标命名空间并提交部署参数（values）
- **THEN** 系统 SHALL 创建状态为 `Pending` 的 AppInstance 记录，并向 operation-worker 提交 Install Operation

#### Scenario: 部署参数校验失败时拒绝创建
- **WHEN** 提交的 values 缺少必填字段或格式非法（如资源限额、StorageClass 不存在）
- **THEN** 系统 SHALL 在创建任何集群资源之前返回字段级校验错误，且不产生 AppInstance 记录

#### Scenario: 目标集群不可达
- **WHEN** 目标集群的隧道连接处于失联状态
- **THEN** 系统 SHALL 拒绝创建请求并提示集群当前不可用，不进入 `Pending` 状态

---

### Requirement: 应用实例生命周期状态机
系统 SHALL 维护每个 AppInstance 唯一的生命周期状态，取值范围为 `Pending`、`Installing`、`Running`、`Upgrading`、`CanaryRolling`、`Scaling`、`Degraded`、`RollingBack`、`Failed`、`Terminating`、`Terminated`，且状态迁移 SHALL 仅由 operation-worker 执行的 Operation 结果驱动。

#### Scenario: 安装成功迁移到运行态
- **WHEN** Install Operation 执行成功且健康检查通过
- **THEN** AppInstance 状态 SHALL 从 `Installing` 迁移为 `Running`

#### Scenario: 安装失败置为 Failed
- **WHEN** Install Operation 执行失败（如镜像拉取失败、资源配额不足）
- **THEN** AppInstance 状态 SHALL 迁移为 `Failed`，并生成 LifecycleEvent 记录失败原因

#### Scenario: 控制台与告警只读状态机
- **WHEN** 控制台或 alert-manager 需要展示/评估 AppInstance 状态
- **THEN** 两者 SHALL 直接读取该状态机的当前值，不得各自维护派生状态副本

---

### Requirement: 滚动升级
系统 SHALL 支持将运行中的 AppInstance 升级到新的 Chart 版本或新的 values，并支持配置滚动策略参数（maxSurge、maxUnavailable）。

#### Scenario: 触发滚动升级
- **WHEN** 用户对 `Running` 状态的 AppInstance 提交新版本或新 values 并指定滚动策略参数
- **THEN** 系统 SHALL 创建新的 AppRelease 记录，AppInstance 状态迁移为 `Upgrading`，并按滚动策略执行升级

#### Scenario: 升级健康检查失败
- **WHEN** 滚动升级过程中新版本 Pod 未通过健康检查
- **THEN** 系统 SHALL 暂停升级、将 AppInstance 状态迁移为 `Degraded`，并触发 alert-manager 告警

#### Scenario: 有状态应用不支持灰度双跑
- **WHEN** AppInstance 关联的工作负载类型为 StatefulSet（有状态）
- **THEN** 系统 SHALL 仅允许滚动升级策略，拒绝以灰度策略提交该实例的升级请求

---

### Requirement: 灰度发布（金丝雀）
系统 SHALL 支持无状态 AppInstance 的灰度发布：并行部署新版本（影子 Release），通过网关加权路由分流流量，按档位放量，并支持手动确认放量档位。

#### Scenario: 创建灰度发布
- **WHEN** 用户对 `Running` 状态的无状态 AppInstance 提交灰度发布请求
- **THEN** 系统 SHALL 创建影子 Release、建立初始权重为 0% 的网关流量分割规则，AppInstance 状态迁移为 `CanaryRolling`

#### Scenario: 手动调整放量档位
- **WHEN** 运维在灰度进行中提交新的权重档位（如从 10% 调整为 30%）
- **THEN** 系统 SHALL 更新网关权重规则并记录一条 LifecycleEvent

#### Scenario: 灰度晋升为正式版本
- **WHEN** 权重达到 100% 且运维确认晋升
- **THEN** 系统 SHALL 将影子 Release 提升为 stable Release、删除权重规则与影子 Release 残留资源，AppInstance 状态回到 `Running`

#### Scenario: 灰度中止回滚
- **WHEN** 灰度进行中运维发起中止
- **THEN** 系统 SHALL 将权重规则清零、删除影子 Release，AppInstance 状态回到 `Running`，且原 stable 版本不受影响

---

### Requirement: 版本回滚
系统 SHALL 支持将 AppInstance 回滚到其历史 AppRelease 记录中的任意一个 revision。

#### Scenario: 回滚到指定历史版本
- **WHEN** 用户对 AppInstance 选择某个历史 revision 并提交回滚
- **THEN** 系统 SHALL 创建新的 AppRelease（引用目标 revision 的 chart 版本与 values），AppInstance 状态迁移为 `RollingBack`，成功后回到 `Running`

#### Scenario: 回滚目标 revision 不存在
- **WHEN** 用户提交的 revision 编号不在该 AppInstance 的发布历史中
- **THEN** 系统 SHALL 拒绝请求并返回明确错误，不产生任何 Operation

---

### Requirement: 扩缩容
系统 SHALL 支持对 AppInstance 手动调整副本数，以及配置基于 CPU / 内存 / 自定义指标的自动扩缩容策略。

#### Scenario: 手动调整副本数
- **WHEN** 用户对 `Running` 状态的 AppInstance 提交新的目标副本数
- **THEN** 系统 SHALL 迁移状态为 `Scaling` 并下发扩缩容 Operation，完成后回到 `Running`

#### Scenario: 设置自动扩缩容策略
- **WHEN** 用户为 AppInstance 配置自动扩缩容策略（最小/最大副本数、触发指标与阈值）
- **THEN** 系统 SHALL 将策略下发为目标集群中的原生自动扩缩容资源，并在实例详情中展示当前策略

#### Scenario: 自动扩容触发记录事件
- **WHEN** 自动扩缩容策略基于指标触发了副本数变化
- **THEN** 系统 SHALL 记录一条 LifecycleEvent，且该变化 SHALL 在发布历史中可见（区别于人工发起的升级/回滚）

---

### Requirement: 应用监控与健康检查
系统 SHALL 持续采集每个 AppInstance 的健康状态（就绪探针结果）与资源用量，并在控制台实时展示；健康状态异常 SHALL 触发 alert-manager 告警。

#### Scenario: 实例健康异常触发告警
- **WHEN** AppInstance 的就绪探针连续失败超过配置阈值
- **THEN** 系统 SHALL 将 AppInstance 状态标记为 `Degraded` 并通过 alert-manager 发送告警通知

#### Scenario: 实例创建时自动生成默认告警规则
- **WHEN** AppInstance 成功进入 `Running` 状态
- **THEN** 系统 SHALL 自动为其创建一组默认的健康与资源使用告警规则（可由用户后续调整或关闭）

---

### Requirement: 发布历史与操作审计
系统 SHALL 记录每个 AppInstance 的完整发布历史（含操作类型、操作人、版本差异摘要、结果），并将所有生命周期操作事件转发至审计子系统。

#### Scenario: 查看发布历史
- **WHEN** 用户查看某个 AppInstance 的详情页
- **THEN** 系统 SHALL 按时间倒序展示其全部 AppRelease 记录，包含操作类型、操作人与结果状态

#### Scenario: 生命周期操作写入审计日志
- **WHEN** 任意部署 / 升级 / 灰度 / 扩缩容 / 回滚 / 卸载操作被执行
- **THEN** 系统 SHALL 生成对应的 LifecycleEvent 并转发至 `pkg/audit` 持久化，可按 AppInstance 过滤查询

---

### Requirement: 基于 IAM 的权限控制
系统 SHALL 对 AppInstance 的所有生命周期操作（部署、升级、灰度、扩缩容、回滚、卸载）执行基于 IAM 角色的鉴权，鉴权范围 SHALL 可限定到集群与命名空间级别。

#### Scenario: 无权限用户操作被拒绝
- **WHEN** 用户对其角色范围之外的集群/命名空间下的 AppInstance 发起升级请求
- **THEN** 系统 SHALL 拒绝该请求并返回 403，同时生成一条被拒绝操作的审计记录

#### Scenario: 只读角色可查看但不可操作
- **WHEN** 具备只读角色的用户访问 AppInstance 详情与发布历史
- **THEN** 系统 SHALL 允许查看，但 SHALL 拒绝任何写操作入口的调用

---

### Requirement: 卸载与资源清理
系统 SHALL 支持卸载 AppInstance，移除其关联的全部集群资源；涉及持久化数据清理的操作 SHALL 要求显式二次确认。

#### Scenario: 卸载并清理孤儿资源
- **WHEN** 用户对 AppInstance 发起卸载
- **THEN** 系统 SHALL 迁移状态为 `Terminating`，移除关联的 Helm Release 及其管理的全部资源，完成后迁移为 `Terminated`

#### Scenario: 卸载涉及持久化数据需二次确认
- **WHEN** AppInstance 关联有持久化卷（PVC）
- **THEN** 系统 SHALL 要求用户显式确认是否一并删除持久化数据，未确认时默认保留 PVC

---

### Requirement: 应用市场版本发布的闭环通知
当 AppInstance 所引用的目录条目在 `app-market` 发布新版本时，系统 SHALL 通知该实例的所有者，并支持在不离开控制台的前提下评估版本差异与发起升级。

#### Scenario: 新版本发布后实例列表出现可升级提示
- **WHEN** `app-market` 发出某目录条目的版本发布事件
- **THEN** 系统 SHALL 为所有引用该条目的 AppInstance 标记"可升级"，并在实例列表中展示徽标

#### Scenario: 一键评估并发起升级
- **WHEN** 用户在"可升级"提示上点击评估
- **THEN** 系统 SHALL 展示新旧版本的 Chart 差异与变更日志摘要，并提供直接进入滚动升级或灰度发布流程的入口
