# Tasks: add-app-lifecycle-management

## 1. 数据模型与存储
- [ ] 1.1 设计并新增数据库迁移：`app_instances`、`app_releases`、`canary_rollouts`、`lifecycle_events`
- [ ] 1.2 在 `pkg/appstore` 或新建 `pkg/applifecycle` 中定义上述实体的 Go 结构体与仓储接口
- [ ] 1.3 编写迁移的单元测试（含回滚迁移）

## 2. API 与鉴权
- [ ] 2.1 在 `cmd/apiserver` 挂载 `/api/v1/app-instances` 路由组
- [ ] 2.2 在 `pkg/iam` 新增 `app-instance` 资源类型与动作（deploy/upgrade/scale/rollback/canary/uninstall）
- [ ] 2.3 接入现有 Auth Middleware，未授权请求返回 403 并写审计
- [ ] 2.4 OpenAPI 文档更新

## 3. 编排引擎扩展（operation-worker）
- [ ] 3.1 定义 Operation 插件接口扩展点（若尚不支持第三方插件注册）
- [ ] 3.2 实现 Install Operation（调用 Helm SDK，通过 cluster-router 下发到目标集群）
- [ ] 3.3 实现 Upgrade Operation（滚动策略参数：maxSurge/maxUnavailable）
- [ ] 3.4 实现 Rollback Operation
- [ ] 3.5 实现 Scale Operation（手动 + 自动扩缩容策略下发为 HPA 资源）
- [ ] 3.6 实现 Uninstall Operation（含孤儿资源清理与 PVC 二次确认）
- [ ] 3.7 状态机落地：每个 Operation 结果驱动 AppInstance 状态迁移，写 LifecycleEvent

## 4. 灰度发布
- [ ] 4.1 影子 Release 创建/删除逻辑（Canary Operation）
- [ ] 4.2 权重调整 API 与 Operation（调用 gateway-provider 新增的加权路由接口）
- [ ] 4.3 晋升（promote）逻辑：canary revision 替换 stable，清理影子 Release 与权重规则
- [ ] 4.4 手动模式的档位化放量 UI 交互（10/30/50/100）
- [ ] 4.5（预留接口，不强制实现）自动模式的 PromQL 判定钩子

## 5. 网关加权路由（gateway-provider）
- [ ] 5.1 设计权重路由规则的数据结构与 CRD/配置格式
- [ ] 5.2 实现权重规则的下发、更新、删除 API
- [ ] 5.3 补充测试用例（现有 55 个测试基础上新增）

## 6. 可观测性与告警集成
- [ ] 6.1 每个 AppInstance 创建时自动生成默认健康 / 资源告警规则（调用 alert-manager 已有能力）
- [ ] 6.2 健康检查失败 → 触发告警 + AppInstance 置为 Degraded
- [ ] 6.3 实例详情页展示实时资源用量（依赖监控数据源，技术栈待确认，见 design.md 未决问题 1）

## 7. 应用市场闭环
- [ ] 7.1 `app-market` 发布新版本时产生 `catalog.version_published` 事件
- [ ] 7.2 `app-lifecycle` 订阅事件并匹配运行实例，生成"可升级"标记
- [ ] 7.3 目录详情页展示关联运行实例列表（跨集群聚合）
- [ ] 7.4 控制台"评估升级"页：chart diff / changelog 展示

## 8. 审计
- [ ] 8.1 LifecycleEvent 全量写入 `pkg/audit`
- [ ] 8.2 审计查询支持按 AppInstance 过滤

## 9. 控制台 UI
- [ ] 9.1 应用实例列表页（状态、版本、集群、可升级徽标）
- [ ] 9.2 实例详情页：版本历史时间线、健康面板、灰度进度条
- [ ] 9.3 灰度发布操作面板（权重滑块 + 晋升/回滚按钮）
- [ ] 9.4 扩缩容配置面板（手动 + 策略）

## 10. 测试与验收
- [ ] 10.1 单元测试覆盖状态机全部合法迁移路径
- [ ] 10.2 集成测试：部署 → 滚动升级 → 回滚 全链路
- [ ] 10.3 集成测试：部署 → 灰度 → 晋升 全链路
- [ ] 10.4 集成测试：应用市场发布新版本 → 实例侧可升级提示 → 升级完成
- [ ] 10.5 故障注入测试：升级健康检查失败自动置 Degraded 并告警
- [ ] 10.6 权限测试：无权限角色调用各接口均返回 403 并有审计记录
