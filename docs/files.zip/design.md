# Design: 应用全生命周期管理

## Context

平台现状（见 `HNB 云原生平台 — 现状总结与计划`）：
- `app-market`：应用市场 + OCI 存储 + Helm 同步，负责"制品"层。
- `operation-worker`：微内核编排引擎，已承载 extension-controller、alert-manager、app-market 等模块的异步操作执行。
- `gateway-provider`：网关管理，已有 55 个测试，但文档未提及加权流量路由能力。
- `cluster-router`：多集群路由、负载均衡、熔断。
- `alert-manager`：告警评估与通知分发。
- `iam` / `audit` / `rbac-syncer`：权限、审计、RBAC 同步。

约束：
- 不新增二进制，优先复用 `operation-worker` 的编排能力（避免第 21 个 cmd 服务带来的部署与运维复杂度）。
- 灰度发布依赖网关加权路由，而 `gateway-provider` 当前未暴露该能力，需要在本变更中一并扩展。
- 平台尚未在文档中确认监控技术栈（假设为 Prometheus 兼容，用于健康/资源指标查询与灰度晋升的自动判定条件）；此为**待确认假设**，见"未决问题"。

## Goals / Non-Goals

**Goals**
- 定义 AppInstance 作为"目录条目在某个集群命名空间中的一次运行实例"的一等公民模型。
- 提供部署、滚动升级、灰度发布、回滚、扩缩容、卸载的统一操作面与状态机。
- 让应用市场的新版本发布事件能够驱动运行实例侧的升级建议（闭环）。
- 复用现有编排、网关、告警、审计、RBAC 基础设施，不重复造轮子。

**Non-Goals（本期不做）**
- 不做跨集群的应用拓扑依赖分析（服务网格级别的调用链）。
- 不做蓝绿发布的独立数据面（本期蓝绿视为灰度权重的两个极值 0/100，复用同一套加权路由能力）。
- 不做基于自定义 CRD 的 Kubernetes Operator（是否引入 Argo Rollouts 等三方 Operator 见"决策"部分）。

## Decisions

### 决策 1：编排复用 operation-worker，而非新建 CRD Operator
**方案对比**：
- A. 引入 Argo Rollouts / Flagger 等成熟 Progressive Delivery Operator。
- B. 在 `operation-worker` 内实现 App Lifecycle Operation 插件，直接调用 Helm SDK + gateway-provider API 完成滚动/灰度。

**选择 B**，理由：
- 平台的核心差异化能力就是"统一编排引擎 + 反向隧道多集群下发"，如果发布策略下沉到每个成员集群各自的 Argo Rollouts CRD，会绕开 `cluster-router` 熔断与 `operation-worker` 的统一任务追踪，导致状态来源分裂。
- 现有 `operation-worker` 已有重试、幂等、NATS 任务队列基础设施，边际成本低。

**权衡**：牺牲了直接使用社区 Progressive Delivery 生态（指标分析库、Web UI）的便利性，未来指标驱动的自动灰度判定需要自建（见未决问题）。

### 决策 2：AppInstance 与 Helm Release 一一对应
一个 AppInstance 对应底层一个 Helm Release（`{cluster}/{namespace}/{release_name}`）。升级 = 新 Helm Revision；灰度 = 并行部署"影子 Release"（`{release_name}-canary`），通过 gateway-provider 权重规则分流，晋升时执行 Helm 层面的 values 合并与主 Release 替换，随后删除影子 Release。

### 决策 3：状态机作为唯一事实来源
AppInstance 状态机由 `operation-worker` 驱动的 Operation 结果更新，控制台/告警/审计均只读该状态机，不各自维护派生状态，避免状态不一致。

```
Pending → Installing → Running
Running → Upgrading → Running | Degraded
Running → CanaryRolling → Running | RolledBack
Running → Scaling → Running
Running/Degraded → RollingBack → Running | Failed
* → Terminating → Terminated
```

### 决策 4：灰度晋升判定分两档
- **手动模式（本期默认）**：运维在控制台按权重档位（10/30/50/100）手动放量，每档需人工确认。
- **自动模式（需 PromQL 规则，依赖路线图中的"告警规则增强"）**：达到某项 SLO 阈值自动放量，指标恶化自动回滚。本期只做手动模式，自动模式的接口预留但不强制实现（见 `app-lifecycle` spec 中该需求标注为"MAY"）。

## Data Model（概念级）

| 实体 | 关键字段 | 说明 |
|---|---|---|
| AppInstance | id, catalog_ref, cluster_id, namespace, release_name, current_revision, desired_revision, strategy(rolling/canary), state, values(jsonb), owner, created_at | 运行实例主体 |
| AppRelease | id, instance_id, revision, chart_version, values_diff, operator, result, created_at | 每次变更的版本快照，用于历史与回滚 |
| CanaryRollout | id, instance_id, stable_revision, canary_revision, weight, gate_mode(manual/auto), status, started_at | 灰度进行中的权重与状态 |
| LifecycleEvent | id, instance_id, type, payload, created_at | 供审计与告警订阅的事件流 |

## API 面（概念级，挂载于 apiserver）

```
POST   /api/v1/app-instances                      创建（从目录部署）
GET    /api/v1/app-instances                       列表（按集群/命名空间/状态过滤）
GET    /api/v1/app-instances/{id}                   详情
POST   /api/v1/app-instances/{id}/upgrade           滚动升级
POST   /api/v1/app-instances/{id}/canary            发起灰度
POST   /api/v1/app-instances/{id}/canary/weight      调整灰度权重
POST   /api/v1/app-instances/{id}/canary/promote     灰度晋升为正式版本
POST   /api/v1/app-instances/{id}/rollback           回滚到指定 revision
POST   /api/v1/app-instances/{id}/scale              手动扩缩容
PUT    /api/v1/app-instances/{id}/autoscale-policy   设置自动扩缩容策略
DELETE /api/v1/app-instances/{id}                    卸载
GET    /api/v1/app-instances/{id}/releases           发布历史
GET    /api/v1/app-instances/{id}/health             实时健康 / 资源用量
```

## 关键时序（文字流程）

**滚动升级**
1. 控制台调用 `upgrade` → apiserver 鉴权（IAM）→ 写入 AppRelease(pending) → 向 operation-worker 提交 Operation。
2. operation-worker 通过 cluster-router 下发到目标集群的 cluster-agent，执行 Helm upgrade（maxSurge/maxUnavailable 由 strategy 参数控制）。
3. 健康检查（readiness + 自定义探针）通过 → AppInstance 回到 Running，AppRelease 标记 success；失败 → 标记 failed，AppInstance 置为 Degraded 并触发 alert-manager 告警。
4. 全程写入 LifecycleEvent → audit 消费。

**灰度发布**
1. 提交 canary → 创建影子 Release（desired_revision），gateway-provider 建立权重规则（初始 canary=0%）。
2. 运维逐档调整权重（或自动模式按 PromQL 规则）；每次调整都是一次 LifecycleEvent + 审计记录。
3. 晋升：canary 权重推到 100% 后，将 canary revision 提升为 stable revision，删除影子 Release 与权重规则，AppInstance 状态回到 Running。
4. 中止：任意档位可直接调用 rollback，权重规则清零、影子 Release 删除，AppInstance 回到 Running（原 stable 版本不受影响）。

**应用市场闭环**
1. `app-market` 发布新版本 → 产生 `catalog.version_published` 事件。
2. `app-lifecycle` 订阅该事件，匹配所有 `catalog_ref` 命中的 AppInstance，生成"可升级"标记与变更摘要（chart diff / changelog）。
3. 控制台在实例列表展示徽标；运维点击"评估升级"查看差异，确认后转入标准升级/灰度流程。

## Risks / Trade-offs

- **自建灰度而非采用 Argo Rollouts**：短期内指标驱动的自动化能力较弱，需要在"告警规则增强"路线图项交付后才能实现自动灰度判定。已在 Non-Goals 与决策 4 中明确范围。
- **影子 Release 的资源翻倍**：灰度期间 stable + canary 同时运行，需在配额/成本估算中提前告知用户（可与"多集群成本分析"扩展联动展示预估）。
- **跨集群灰度**：本期只支持单集群内灰度；多集群同步灰度（例如东西两个 Region 各自放量）列为 v2 增强，需要 cluster-router 感知灰度状态，本期不做。

## 未决问题（Open Questions）

1. 平台监控技术栈尚未在现状文档中明确（Prometheus？自研？），自动灰度判定依赖 PromQL，需与基础设施团队确认后再排期"自动模式"。
2. 持久化存储类应用（StatefulSet）滚动升级是否需要额外的"数据兼容性检查"步骤（例如数据库版本升级前的 schema 校验）？本期先支持无状态应用的滚动/灰度，有状态应用仅支持滚动升级（不支持灰度双跑，因存储无法安全复制）。
3. 是否需要审批工作流（对应路线图"应用商店完善"中的审批工作流）介入生产环境的升级操作？本期假设走已有 IAM 角色权限即可，不引入独立审批流。
